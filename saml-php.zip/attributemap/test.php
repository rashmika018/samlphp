<?php

$attributemap = [
    'mobile' => 'urn:mace:dir:attribute-def:mobile'
];
