<?php

declare(strict_types=1);

// Hook detection should not load this file since it does not conform to the hook naming scheme
