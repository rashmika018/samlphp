# Dummy module

For some unit tests we need a module that has a specific setup or issues.
