<?php

declare(strict_types=1);

/*
 */

$metadata['urn:x-simplesamlphp:other-idp'] = [
    'SingleSignOnService' => 'https://example.org/module.php/saml/idp/singleSignOnService',
];
