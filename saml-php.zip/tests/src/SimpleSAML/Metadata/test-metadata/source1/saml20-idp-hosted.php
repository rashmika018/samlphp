<?php

declare(strict_types=1);

/*
 */

$metadata['urn:x-simplesamlphp:some-idp'] = [
    'auth' => 'phpunit',
    'host' => 'localhost',
];
